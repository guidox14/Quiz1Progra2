﻿Imports System.Data.SqlClient

Public Class Form1

    Private Sub BuscarButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BuscarButton.Click
        Dim precioMin, precioMax As Integer

        precioMin = CType(precioMinTextBox.Text, Integer)
        precioMax = CType(precioMaxTextBox.Text, Integer)

        DevolverArticulos(precioMin, precioMax)
    End Sub

    Private Function DevolverArticulos(ByVal pMin As Integer, ByVal pMax As Integer) As Boolean
        Dim connectionBuilder As New SqlConnectionStringBuilder
        connectionBuilder.DataSource = "ADRIAN-PC\SQLEXPRESS"
        connectionBuilder.InitialCatalog = "Quiz1"
        connectionBuilder.IntegratedSecurity = True

        Dim conexion As New SqlConnection(connectionBuilder.ConnectionString)
        conexion.Open()

        Dim sqlCommand As SqlCommand = conexion.CreateCommand
        sqlCommand.Connection = conexion

        Dim command As String = "SELECT NombreArticulo from Articulos where Precio > " + pMin.ToString() + " AND Precio < " + pMax.ToString() + ";"
        sqlCommand.CommandText = command
        Dim sqlReader As SqlDataReader

        sqlReader = sqlCommand.ExecuteReader()

        Dim Iarticulo As IDataRecord
        Dim articulo As String = ""

        While (sqlReader.Read())
            Iarticulo = CType(sqlReader, IDataRecord)
            articulo += String.Format("{0}, ", Iarticulo(0))
        End While

        conexion.Close()

        MsgBox(articulo, MsgBoxStyle.Information, "Objetos seleccionados")

        Return False

    End Function

    Private Function ReadSingleRow(ByVal record As IDataRecord) As String
        Return record(0)
    End Function

End Class
